ls -la
